#constants
N = 10  #maxcard
S = 4   #number of stages
T = 43  #number of tasks
M = 24  #number of machines
C = 10  #number of characteristics

# acc["vars"]=0
# acc["cstr"]=0

def stage_vars(acc): #stage.var(machine)
    acc["vars"] += S*N #each stage has a N machine variables
    
    # fix 1, opposite
    
    # fix 2 Ordered Sets
    acc["cstr"] += 1 #each stage has a N machine variables



def stage_size(acc): #stage.var(machines).size() <= stage.maxMachines
    acc["vars"] += S #dummy count
    acc["cstr"] += S*2 #dummy count and dummycount<=max

def task_vars(acc): #task.var(stage)
    acc["vars"] += T #each task has a stage variable

def task_pred(acc): #task.var(stage).stageID >= task.prev.var(stage).stageID
    acc["vars"] += T #each task must have a "local" stage.StageID
    acc["cstr"] += T #each "local" StageID must be coherent
    acc["cstr"] += T-1 #each has >= constraints (none for first)

def task_char(acc): #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    acc["vars"] += T*N*2 #each task must have "local" stage.machines and pointer
    acc["cstr"] += T*N*2 #each task must have "local" stage.machines element and pointer
    acc["vars"] += T*N*N*2 #each task must have "local" stage.machines.characteristics
    acc["cstr"] += T*N*N*2 #each task must have "local" stage.machines.characteristics element
    # acc["vars"] += T*N #each task must have "local" their.characteristics for the CP (constVars)
    acc["vars"] += T*C #each task's characteristics has a gcc representation for the IncludesAll
    acc["cstr"] += T #said gcc
    acc["vars"] += T*N*C #each task's machines' characteristics  has a gcc representation for the IncludesAll
    acc["cstr"] += T*N #said gccs
    acc["vars"] += T*N #needs bools to check weather GCCs apply (conclusion)
    acc["cstr"] += T*N #reified constraints to check weather GCCs apply (premise)
    acc["cstr"] += T*N #implication of machine gcc (forall)
    acc["cstr"] += T*N #implication of machine gcc includes (forall)
    acc["cstr"] += T*N*C # includes (gcc(task.char)[i]<=gcc(machines[j].char)[i])

def task_char_constmachines(acc): #task.var(stage).machines.forall(m|m.characteristics->includesAll(task.characteristics))
    acc["vars"] += T*N*2 #each task must have "local" stage.machines
    acc["cstr"] += T*N*2 #each task must have "local" stage.machines element
    acc["vars"] += T*N*N*2 #each task must have "local" stage.machines.characteristics
    acc["cstr"] += T*N*N*2 #each task must have "local" stage.machines.characteristics element
    # acc["vars"] += T*N #each task must have "local" their.characteristics for the CP (constVars)
    acc["vars"] += T*C #each task's characteristics has a gcc representation for the IncludesAll
    acc["cstr"] += T #said gcc
    acc["vars"] += T*N*C #each task's machines' characteristics  has a gcc representation for the IncludesAll
    acc["cstr"] += T*N #said gccs
    acc["vars"] += T*N #needs bools to check weather GCCs apply (conclusion)
    acc["cstr"] += T*N #reified constraints to check weather GCCs apply (premise)
    acc["cstr"] += T*N #implication of machine gcc (forall)
    acc["cstr"] += T*N #implication of machine gcc includes (forall)
    acc["cstr"] += T*N*C # includes (gcc(task.char)[i]<=gcc(machines[j].char)[i])

def task_char_conststages(acc): #task.stage.var(machines).forall(m|m.characteristics->includesAll(task.characteristics))
    acc["vars"] += T*N*N*2 #each task must have "local" stage.machines.characteristics
    acc["cstr"] += T*N*N*2 #each task must have "local" stage.machines.characteristics element
    # acc["vars"] += T*N #each task must have "local" their.characteristics for the CP (constVars)
    acc["vars"] += T*C #each task's characteristics has a gcc representation for the IncludesAll
    acc["cstr"] += T #said gcc
    acc["vars"] += T*N*C #each task's machines' characteristics  has a gcc representation for the IncludesAll
    acc["cstr"] += T*N #said gccs
    acc["vars"] += T*N #needs bools to check weather GCCs apply (conclusion)
    acc["cstr"] += T*N #reified constraints to check weather GCCs apply (premise)
    acc["cstr"] += T*N #implication of machine gcc (forall)
    acc["cstr"] += T*N #implication of machine gcc includes (forall)
    acc["cstr"] += T*N*C # includes (gcc(task.char)[i]<=gcc(machines[j].char)[i])

#cstr are /\
def task_char_bool(acc): #task.var(stage).var(machine,bool).forall(m|m.characteristics->includesAll(task.characteristics))
    acc["vars"] += T*M #each task must have "local" stage.machines bools, pointer
    acc["cstr"] += T*N #each task must have "local" stage.machines element, pointer
    acc["vars"] += T*C #each task must have "local" stage.machines.characteristics bools
    acc["cstr"] += T*M*C*2 #to get the above characteristics from the machines, machines activate char rows, active char colmumns activate output, thought a const matrix of Bools
    acc["vars"] += T*C #each task must have "local" their.characteristics for the CP (constVars)
    acc["cstr"] += T*C #task.char -> T.stage.Machine.Char

#cstr are +
def task_char_bag(acc): #task.var(stage).var(machine,gcc).forall(m|m.characteristics->includesAll(task.characteristics))
    acc["vars"] += T*M #each task must have "local" stage.machines bools, pointer
    acc["cstr"] += T*N #each task must have "local" stage.machines element, pointer
    acc["vars"] += T*C #each task must have "local" stage.machines.characteristics bools
    acc["cstr"] += T*M*C*2 #to get the above characteristics from the machines, machines activate char rows, active char colmumns activate output, thought a const matrix of Bools
    acc["vars"] += T*C #each task must have "local" their.characteristics for the CP (constVars)
    acc["cstr"] += T*C #task.char -> T.stage.Machine.Char

def task_char_ATOL(acc): #Machines.AllInstances()->select(m | m.characteristics->includesAll(t.characteristics))->includesAll(t.var(stage).var(machines))
    acc["vars"] += T*N*2 #each task must have "local" stage.machines
    acc["cstr"] += T*M*2 #each task must have "local" stage.machines element
    acc["vars"] += T*M #each task must have "local" stage.machines gcc
    acc["cstr"] += T #said gcc
    acc["vars"] += T*M #ATOL list of compatible machines (gcc or bool)
    acc["cstr"] += T*M #ATOLgcc_m >= STAGEgcc_m 

def task_char_ATOL_stage(acc): #Stages.AllInstances()->select(s | s.machines->forall(m|m.characteristics->includesAll(t.characteristics)))->includes(t.var(stage))
    acc["vars"] += T #ATOL list of compatible stages (ints)
    acc["cstr"] += T #member #includes
    #instead of (includesAll): 2(gccs) and |stage|(>=) 



def factory_objective(acc): #stages.var(machines)->sum(m | m.cost)
    acc["vars"] += 1 #sum value of total machine cost
    acc["cstr"] += 1 #sum value of total machine cost
    acc["vars"] += S*N #for each stage's machines, we need the cost in a var,
    acc["cstr"] += S*N #for each stage's machines, we need the cost in a var, thus an element
    acc["cstr"] += 1 #minimize


def Problem_whole(): #1,2,3,4
    acc = {"vars" : 0,"cstr" : 0}
    
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)

    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))

    return acc

def Problem_StageSize(): #1
    acc = {"vars" : 0,"cstr" : 0}
    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
 
    return acc

def Problem_TaskPred(): #2
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    # stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    # task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_TaskChar(): #3
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_TaskChar_bag(): #3b
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_bag(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_TaskChar_bool(): #3s
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_bool(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_TaskChar_constMachines(): #3
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    # stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_constmachines(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_TaskChar_conststages(): #3
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    # task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_conststages(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_Objective(): #4
    acc = {"vars" : 0,"cstr" : 0}
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    # task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    # task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_Machines_obj(): #1,4
    acc = {"vars" : 0,"cstr" : 0}
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    # task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    # task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_Machines_chr(): #1,3
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    # task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_conststages(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_Machines_obj_chr(): #1,3,4
    acc = {"vars" : 0,"cstr" : 0}
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    # task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_conststages(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_Machines_no_size(): #3,4
    acc = {"vars" : 0,"cstr" : 0}
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    # task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_conststages(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_Stages(): #2,3
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    # stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_constmachines(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))
    return acc

def Problem_SM_size(): #1,2,3
    acc = {"vars" : 0,"cstr" : 0}
    
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)

    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))

    return acc

def Problem_SM_obj(): #2,3,4
    acc = {"vars" : 0,"cstr" : 0}
    
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)

    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))

    return acc


def Problem_whole_ATOL():
    acc = {"vars" : 0,"cstr" : 0}
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_ATOL(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics))

    return acc

def Problem_TaskChar_ATOL():
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_ATOL(acc) #Machines.AllInstances()->select(m | m.characteristics->includesAll(t.characteristics))->includesAll(t.var(stage).var(machines))

    return acc

def Problem_TaskChar_ATOL_stage():
    acc = {"vars" : 0,"cstr" : 0}
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)
    # stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    task_vars(acc) #task.var(stage)
    # task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    task_char_ATOL_stage(acc) #Stages.AllInstances()->select(s | s.machines->forall(m |m.characteristics->includesAll(t.characteristics)))->includes(t.var(stage))

    return acc

# print(Problem_whole())
# # #print singles
# print(Problem_StageSize()) #all machines are the same, we just need to choose a number of machines for each stage with no constraints
# print(Problem_TaskPred()) #all stages are the same, just need to respect order
# print(Problem_TaskChar()) #tasks can be done in any order, but needs the right machines in the right stages
# print(Problem_TaskChar_constMachines()) #tasks can be done in any order, but the right stage (machines are already set)
# print(Problem_TaskChar_conststages()) #tasks can be done in any order, and have be divided among stages, machines need to be associated with each stage
# print(Problem_Objective()) #all machines have same chars but different costs, we need to minimise cost

# #print machines sub-problems
# print(Problem_Machines_obj())
# print(Problem_Machines_chr())
# print(Problem_Machines_obj_chr())
# print(Problem_Machines_no_size())

# #print stage sub-problems
# print(Problem_Stages())

# #print stage,machines sub-problems
# print(Problem_SM_size()) #1,2,3
# print(Problem_SM_obj()) #2,3,4

# #print char encodings
# print(Problem_TaskChar())
# print(Problem_TaskChar_bag())
# print(Problem_TaskChar_bool())

#print ATOL
# print(Problem_TaskChar())
# print(Problem_TaskChar_constMachines())
# print(Problem_TaskChar_ATOL())
# print(Problem_TaskChar_ATOL_stage())




# Eval table 1.
print("table 1")
str = "{} & {} & {:_} & {:_} \\\\\\hline"
print(str.format("1 (Size)","machines",Problem_StageSize()["vars"],Problem_StageSize()["cstr"]).replace('_',' ')) #all machines are the same, we just need to choose a number of machines for each stage with no constraints
print(str.format("2 (Precedence)","stage",Problem_TaskPred()["vars"],Problem_TaskPred()["cstr"]).replace('_',' ')) #all stages are the same, just need to respect order
print(str.format("3 (Characteristic)","stage,machines",Problem_TaskChar()["vars"],Problem_TaskChar()["cstr"]).replace('_',' ')) #tasks can be done in any order, but needs the right machines in the right stages
print(str.format("3 (Characteristic)","stage",Problem_TaskChar_constMachines()["vars"],Problem_TaskChar_constMachines()["cstr"]).replace('_',' ')) #tasks can be done in any order, but the right stage (machines are already set)
print(str.format("3 (Characteristic)","machines",Problem_TaskChar_conststages()["vars"],Problem_TaskChar_conststages()["cstr"]).replace('_',' ')) #tasks can be done in any order, and have be divided among stages, machines need to be associated with each stage
print(str.format("4 (Budget)","machines",Problem_Objective()["vars"],Problem_Objective()["cstr"]).replace('_',' ')) #all machines have same chars but different costs, we need to minimise cost

def Problem_SM_1_2():
    acc = {"vars" : 0,"cstr" : 0}
    
    # factory_objective(acc) #stages.var(machines)->sum(m | m.cost)

    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    # task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics)) 
    return acc
print(str.format("1,2","stage,machines",Problem_SM_1_2()["vars"],Problem_SM_1_2()["cstr"]).replace('_',' '))


print(str.format("1,3","machines",Problem_Machines_chr()["vars"],Problem_Machines_chr()["cstr"]).replace('_',' ')) #1,3
print(str.format("1,4","machines",Problem_Machines_obj()["vars"],Problem_Machines_obj()["cstr"]).replace('_',' ')) #1,4
print(str.format("2,3","stages",Problem_Stages()["vars"],Problem_Stages()["cstr"]).replace('_',' ')) #2,3

def Problem_SM_2_4():
    acc = {"vars" : 0,"cstr" : 0}
    
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)

    stage_vars(acc) #stage.var(machine)
    # stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    # task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics)) 
    return acc

print(str.format("1,4","stage,machines",Problem_SM_2_4()["vars"],Problem_SM_2_4()["cstr"]).replace('_',' '))


print(str.format("3,4","machines",Problem_Machines_no_size()["vars"],Problem_Machines_no_size()["cstr"]).replace('_',' ')) #3,4


print(str.format("1,2,3","stage,machines",Problem_SM_size()["vars"],Problem_SM_size()["cstr"]).replace('_',' ')) #1,2,3

def Problem_SM_1_2_4():
    acc = {"vars" : 0,"cstr" : 0}
    
    factory_objective(acc) #stages.var(machines)->sum(m | m.cost)

    stage_vars(acc) #stage.var(machine)
    stage_size(acc) #stage.var(machines).size() <= stage.maxMachines
    
    task_vars(acc) #task.var(stage)
    task_pred(acc) #task.var(stage).stageID >= task.prev.var(stage).stageID
    # task_char(acc) #task.var(stage).var(machine).forall(m|m.characteristics->includesAll(task.characteristics)) 
    return acc
print(str.format("1,2,4","stage,machines",Problem_SM_1_2_4()["vars"],Problem_SM_1_2_4()["cstr"]).replace('_',' '))


print(str.format("1,3,4","machines",Problem_Machines_obj_chr()["vars"],Problem_Machines_obj_chr()["cstr"]).replace('_',' ')) #1,3,4
print(str.format("2,3,4","stage,machines",Problem_SM_obj()["vars"],Problem_SM_obj()["cstr"]).replace('_',' ')) #2,3,4


print(str.format("1,2,3,4","stage,machines",Problem_whole()["vars"],Problem_whole()["cstr"]).replace('_',' ')) #1,2,3,4



str2 = "{} & {} & {:_} & {} & {:_} \\\\\\{}"

# Eval Table 2
print("seq bag set table")
print(str2.format("","link",Problem_TaskChar()["vars"],"M",Problem_TaskChar()["cstr"],"cline{2-5}").replace('_',' '))
print(str2.format("","occurrence",Problem_TaskChar_bag()["vars"],"N",Problem_TaskChar_bag()["cstr"],"cline{2-5}").replace('_',' '))
print(str2.format("","occurrence",Problem_TaskChar_bool()["vars"],"2",Problem_TaskChar_bool()["cstr"],"hline").replace('_',' '))

# Eval Table 3
print("ATOL table")
print(str.format("Normal","stage,machines",Problem_TaskChar()["vars"],Problem_TaskChar()["cstr"]).replace('_',' '))
print(str.format("ATOL","stage,machines",Problem_TaskChar_ATOL()["vars"],Problem_TaskChar_ATOL()["cstr"]).replace('_',' '))
print(str.format("Normal","stage",Problem_TaskChar_constMachines()["vars"],Problem_TaskChar_constMachines()["cstr"]).replace('_',' '))
print(str.format("ATOL","stage",Problem_TaskChar_ATOL_stage()["vars"],Problem_TaskChar_ATOL_stage()["cstr"]).replace('_',' '))